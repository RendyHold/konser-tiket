<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Aplikasi Tiket</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50">
    
    <nav class="bg-white shadow mb-6">
        <div class="container mx-auto flex justify-between items-center px-4 py-3">
            <div class="text-xl font-bold">KonserScan</div>
            <div class="space-x-4">
                <?php if(auth()->guard()->check()): ?>
                    
                    <a href="<?php echo e(route('dashboard')); ?>" class="hover:underline">Dashboard</a>

                    
                    <?php if(Auth::user()->role === 'user'): ?>
                        <a href="<?php echo e(route('ticket.show')); ?>" class="hover:underline">Tiket Saya</a>
                    <?php endif; ?>

                    
                    <?php if(Auth::user()->role === 'petugas'): ?>
                        <a href="<?php echo e(route('ticket.scan')); ?>" class="hover:underline">Scan Tiket</a>
                    <?php endif; ?>

                    
                    <?php if(Auth::user()->role === 'admin'): ?>
                        <a href="<?php echo e(route('ticket.scan')); ?>" class="hover:underline">Scan Tiket</a>
                        <a href="<?php echo e(route('admin.scans')); ?>" class="hover:underline">Daftar Scan</a>
                        <a href="<?php echo e(route('admin.users')); ?>" class="hover:underline">Manajemen User</a>
                    <?php endif; ?>

                    
                    <form action="<?php echo e(route('logout')); ?>" method="POST" class="inline">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="hover:underline text-red-600">Logout</button>
                    </form>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>" class="hover:underline">Login</a>
                    <a href="<?php echo e(route('register')); ?>" class="hover:underline">Register</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    
    <div class="container mx-auto">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</body>
</html>
<?php /**PATH C:\Coding FullStack\konserscan\konser-tiket\resources\views\app.blade.php ENDPATH**/ ?>