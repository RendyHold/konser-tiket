<?php $__env->startSection('title','Edit Acara'); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
  <?php if($errors->any()): ?>
    <div class="err">
      <ul style="margin:0;padding-left:18px;">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($e); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
  <?php endif; ?>
  <form method="POST" action="<?php echo e(route('acara.update',$acara)); ?>">
    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
    <p><label>Nama</label><br>
      <input name="nama" value="<?php echo e(old('nama',$acara->nama)); ?>" required>
    </p>
    <p><label>Tanggal</label><br>
      <input type="datetime-local" name="tanggal"
             value="<?php echo e(old('tanggal',$acara->tanggal->format('Y-m-d\TH:i'))); ?>" required>
    </p>
    <p><label>Lokasi</label><br>
      <input name="lokasi" value="<?php echo e(old('lokasi',$acara->lokasi)); ?>">
    </p>
    <p><label>Kuota (0 = tak terbatas)</label><br>
      <input type="number" name="kuota" min="0" value="<?php echo e(old('kuota',$acara->kuota)); ?>">
    </p>
    <button>Update</button>
    <a href="<?php echo e(route('acara.index')); ?>">Kembali</a>
  </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Coding FullStack\konserscan\konser-tiket\resources\views\acara\edit.blade.php ENDPATH**/ ?>