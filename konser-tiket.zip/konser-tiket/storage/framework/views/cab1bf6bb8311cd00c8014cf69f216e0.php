<?php $__env->startSection('title','Riwayat Scan'); ?>

<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="card">
    <strong><?php echo e($pd->kode_tiket); ?></strong><br>
    <?php echo e($pd->mahasiswa->npm); ?> � <?php echo e($pd->mahasiswa->nama); ?><br>
    Acara: <?php echo e($pd->acara->nama); ?><br>
    Waktu scan: <?php echo e($pd->scanned_at); ?>

  </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php if(method_exists($list,'links')): ?>
  <?php echo e($list->links()); ?>

<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Coding FullStack\konserscan\konser-tiket\resources\views\scan\history.blade.php ENDPATH**/ ?>