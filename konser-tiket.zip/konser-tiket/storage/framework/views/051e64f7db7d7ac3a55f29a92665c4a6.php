<?php $__env->startSection('title','Tiket Kamu'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
  <p><strong>Kode:</strong> <?php echo e($pd->kode_tiket); ?></p>
  <p><strong>NPM:</strong> <?php echo e($pd->mahasiswa->npm); ?> � <?php echo e($pd->mahasiswa->nama); ?></p>
  <p><strong>Acara:</strong> <?php echo e($pd->acara->nama); ?> (<?php echo e($pd->acara->tanggal->format('d M Y H:i')); ?>)</p>
  <div style="margin-top:12px"><?php echo $qrSvg; ?></div>
  <small>Tunjukkan QR ini di pintu masuk. Satu NPM hanya satu tiket per acara.</small>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Coding FullStack\konserscan\konser-tiket\resources\views\daftar\tiket.blade.php ENDPATH**/ ?>