<?php $__env->startSection('content'); ?>
<div class="container mx-auto max-w-6xl p-4">
  <h1 class="text-2xl font-bold mb-4">Daftar Bukti SIAK</h1>

  <form class="flex gap-2 mb-4">
    <input type="text" name="q" value="<?php echo e(request('q')); ?>" placeholder="Cari kode/nama/NPM" class="border px-2 py-1 rounded">
    <input type="date" name="from" value="<?php echo e(request('from')); ?>" class="border px-2 py-1 rounded">
    <input type="date" name="to"   value="<?php echo e(request('to')); ?>" class="border px-2 py-1 rounded">
    <button class="bg-blue-600 text-white px-3 py-1 rounded">Filter</button>
  </form>

  <table class="w-full border">
    <thead>
      <tr class="bg-gray-100">
        <th class="p-2 border">Waktu Klaim</th>
        <th class="p-2 border">Kode</th>
        <th class="p-2 border">NPM</th>
        <th class="p-2 border">Bukti SIAK</th>
        <th class="p-2 border">Pemilik</th>
        <th class="p-2 border">Aksi</th>
      </tr>
    </thead>
    <tbody>
      <?php $__empty_1 = true; $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php
          $proof = $t->npm_proof_path ? asset('storage/'.$t->npm_proof_path) : null;
          $ext   = $t->npm_proof_path ? strtolower(pathinfo($t->npm_proof_path, PATHINFO_EXTENSION)) : null;
          $isImg = in_array($ext, ['jpg','jpeg','png','webp']);
        ?>
        <tr>
          <td class="p-2 border"><?php echo e($t->claimed_at); ?></td>
          <td class="p-2 border font-mono"><?php echo e($t->code); ?></td>
          <td class="p-2 border"><?php echo e($t->npm); ?></td>
          <td class="p-2 border">
            <?php if($proof): ?>
              <?php if($isImg): ?>
                <a href="<?php echo e($proof); ?>" target="_blank" title="Lihat bukti">
                  <img src="<?php echo e($proof); ?>" alt="bukti" class="h-12 w-auto inline-block rounded border">
                </a>
              <?php else: ?>
                <a href="<?php echo e($proof); ?>" target="_blank" class="text-blue-600 underline">Lihat PDF</a>
              <?php endif; ?>
            <?php else: ?>
              <span class="text-gray-500">-</span>
            <?php endif; ?>
          </td>
          <td class="p-2 border"><?php echo e($t->user->name ?? '-'); ?></td>
          <td class="p-2 border">
            <?php if($t->npm_proof_path): ?>
              <a href="<?php echo e(route('admin.proofs.download', $t)); ?>"
                 class="px-3 py-1 rounded bg-gray-800 text-white text-sm">Download</a>
              <a href="<?php echo e($proof); ?>" target="_blank"
                 class="ml-2 px-3 py-1 rounded bg-blue-600 text-white text-sm">Buka</a>
            <?php else: ?>
              -
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td class="p-2 border text-center" colspan="6">Belum ada bukti</td></tr>
      <?php endif; ?>
    </tbody>
  </table>

  <div class="mt-3"><?php echo e($tickets->links()); ?></div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Coding FullStack\konserscan\konser-tiket\resources\views\admin\proofs.blade.php ENDPATH**/ ?>