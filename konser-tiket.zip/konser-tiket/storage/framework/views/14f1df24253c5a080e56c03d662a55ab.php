<?php $__env->startSection('content'); ?>
<div class="container p-4">
  <h1 class="text-2xl font-bold mb-4">Dashboard Petugas</h1>
  <a href="<?php echo e(route('ticket.scan')); ?>" class="px-4 py-2 bg-green-600 text-white rounded">🔍 Buka Scanner</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Coding FullStack\konserscan\konser-tiket\resources\views\dashboard\petugas.blade.php ENDPATH**/ ?>