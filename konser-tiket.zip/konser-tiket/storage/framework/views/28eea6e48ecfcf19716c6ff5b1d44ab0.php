<?php $__env->startSection('content'); ?>
<div class="container p-4">
  <h1 class="text-2xl font-bold mb-4">Dashboard User</h1>
  <a href="<?php echo e(route('ticket.show')); ?>" class="text-blue-600 underline">Lihat Tiket Saya</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Coding FullStack\konserscan\konser-tiket\resources\views\dashboard\user.blade.php ENDPATH**/ ?>