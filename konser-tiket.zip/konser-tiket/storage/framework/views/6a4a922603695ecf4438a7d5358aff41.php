<?php $__env->startSection('title','Daftar Acara'); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
  <a href="<?php echo e(route('acara.create')); ?>">+ Tambah Acara</a>
</div>

<?php if(session('ok')): ?> <div class="card ok"><?php echo e(session('ok')); ?></div> <?php endif; ?>

<?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="card">
    <strong><?php echo e($a->nama); ?></strong><br>
    <?php echo e($a->tanggal->format('d M Y H:i')); ?> <?php if($a->lokasi): ?> � <?php echo e($a->lokasi); ?> <?php endif; ?>
    <div style="margin-top:8px">
      <a href="<?php echo e(route('acara.edit',$a)); ?>">Edit</a>
      <form method="POST" action="<?php echo e(route('acara.destroy',$a)); ?>" style="display:inline">
        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
        <button onclick="return confirm('Hapus acara ini?')">Hapus</button>
      </form>
    </div>
  </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php if(method_exists($list,'links')): ?>
  <?php echo e($list->links()); ?>

<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Coding FullStack\konserscan\konser-tiket\resources\views\acara\index.blade.php ENDPATH**/ ?>