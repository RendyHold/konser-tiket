<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <title><?php echo e($title ?? 'KonserScan'); ?></title>

  
  <script src="https://cdn.tailwindcss.com"></script>

  <?php echo $__env->yieldPushContent('head'); ?>
</head>
<body class="bg-gray-50 text-gray-900 min-h-screen flex flex-col">

  
  <nav class="bg-white shadow-sm sticky top-0 z-40">
    <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
      <div class="flex h-14 items-center justify-between">

        
        <div class="flex items-center">
          <a href="<?php echo e(Route::has('dashboard') ? route('dashboard') : url('/')); ?>"
             class="text-lg font-bold text-gray-900">
            KonserScan
          </a>
        </div>

        
        <button id="navToggle"
                class="md:hidden inline-flex items-center justify-center rounded p-2 hover:bg-gray-100"
                aria-label="Toggle navigation">
          <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none"
               viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                  d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>

        <?php
          $user = Auth::user();
          $role = $user->role ?? 'guest';
          $hasTicket = $user ? \App\Models\Ticket::where('user_id', $user->id)->exists() : false;
        ?>

        
        <ul id="navMenu"
            class="hidden md:flex list-none items-center gap-6 text-sm font-medium text-gray-700">
          <?php if(auth()->guard()->check()): ?>
            
            <?php if(Route::has('dashboard')): ?>
              <li>
                <a href="<?php echo e(route('dashboard')); ?>"
                   class="hover:text-gray-900 <?php echo e(request()->routeIs('dashboard') ? 'underline font-semibold' : ''); ?>">
                  Dashboard
                </a>
              </li>
            <?php endif; ?>

            
            <?php if($role === 'user'): ?>
              <?php if(Route::has('ticket.show')): ?>
                <li>
                  <a href="<?php echo e(route('ticket.show')); ?>"
                     class="hover:text-gray-900 <?php echo e(request()->routeIs('ticket.show') ? 'underline font-semibold' : ''); ?>">
                    Tiket Saya
                  </a>
                </li>
              <?php endif; ?>
              <?php if(!$hasTicket && Route::has('ticket.form')): ?>
                <li>
                  <a href="<?php echo e(route('ticket.form')); ?>"
                     class="hover:text-gray-900 <?php echo e(request()->routeIs('ticket.form') ? 'underline font-semibold' : ''); ?>">
                    Klaim Tiket
                  </a>
                </li>
              <?php endif; ?>
            <?php endif; ?>

            
            <?php if(in_array($role, ['petugas','admin'])): ?>
              <?php if(Route::has('ticket.scan')): ?>
                <li>
                  <a href="<?php echo e(route('ticket.scan')); ?>"
                     class="hover:text-gray-900 <?php echo e(request()->routeIs('ticket.scan') ? 'underline font-semibold' : ''); ?>">
                    Scan
                  </a>
                </li>
              <?php endif; ?>
              <?php if(Route::has('admin.scans')): ?>
                <li>
                  <a href="<?php echo e(route('admin.scans')); ?>"
                     class="hover:text-gray-900 <?php echo e(request()->routeIs('admin.scans') ? 'underline font-semibold' : ''); ?>">
                    Daftar Scan
                  </a>
                </li>
              <?php endif; ?>
              <?php if(Route::has('admin.proofs')): ?>
                <li>
                  <a href="<?php echo e(route('admin.proofs')); ?>"
                     class="hover:text-gray-900 <?php echo e(request()->routeIs('admin.proofs') ? 'underline font-semibold' : ''); ?>">
                    Bukti SIAK
                  </a>
                </li>
              <?php endif; ?>
              <?php if($role === 'admin' && Route::has('admin.users')): ?>
                <li>
                  <a href="<?php echo e(route('admin.users')); ?>"
                     class="hover:text-gray-900 <?php echo e(request()->routeIs('admin.users') ? 'underline font-semibold' : ''); ?>">
                    Manajemen User
                  </a>
                </li>
              <?php endif; ?>
            <?php endif; ?>
          <?php endif; ?>

          <?php if(auth()->guard()->guest()): ?>
            <?php if(Route::has('login')): ?>
              <li><a href="<?php echo e(route('login')); ?>" class="hover:text-gray-900">Login</a></li>
            <?php endif; ?>
            <?php if(Route::has('register')): ?>
              <li><a href="<?php echo e(route('register')); ?>" class="hover:text-gray-900">Register</a></li>
            <?php endif; ?>
          <?php endif; ?>
        </ul>

        
        <div class="hidden md:flex items-center">
          <?php if(auth()->guard()->check()): ?>
            <?php if(Route::has('logout')): ?>
              <a href="#"
                 class="text-sm font-medium text-red-600 hover:text-red-700"
                 onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                Logout
              </a>
            <?php endif; ?>
          <?php endif; ?>
        </div>
      </div>

      
      <div id="mobileMenu" class="md:hidden hidden border-t">
        <ul class="list-none py-3 space-y-2 text-sm font-medium text-gray-700">
          <?php if(auth()->guard()->check()): ?>
            <?php if(Route::has('dashboard')): ?>
              <li><a href="<?php echo e(route('dashboard')); ?>" class="block px-2 py-1 <?php echo e(request()->routeIs('dashboard') ? 'underline font-semibold' : ''); ?>">Dashboard</a></li>
            <?php endif; ?>

            <?php if($role === 'user'): ?>
              <?php if(Route::has('ticket.show')): ?>
                <li><a href="<?php echo e(route('ticket.show')); ?>" class="block px-2 py-1 <?php echo e(request()->routeIs('ticket.show') ? 'underline font-semibold' : ''); ?>">Tiket Saya</a></li>
              <?php endif; ?>
              <?php if(!$hasTicket && Route::has('ticket.form')): ?>
                <li><a href="<?php echo e(route('ticket.form')); ?>" class="block px-2 py-1 <?php echo e(request()->routeIs('ticket.form') ? 'underline font-semibold' : ''); ?>">Klaim Tiket</a></li>
              <?php endif; ?>
            <?php endif; ?>

            <?php if(in_array($role, ['petugas','admin'])): ?>
              <?php if(Route::has('ticket.scan')): ?>
                <li><a href="<?php echo e(route('ticket.scan')); ?>" class="block px-2 py-1 <?php echo e(request()->routeIs('ticket.scan') ? 'underline font-semibold' : ''); ?>">Scan</a></li>
              <?php endif; ?>
              <?php if(Route::has('admin.scans')): ?>
                <li><a href="<?php echo e(route('admin.scans')); ?>" class="block px-2 py-1 <?php echo e(request()->routeIs('admin.scans') ? 'underline font-semibold' : ''); ?>">Daftar Scan</a></li>
              <?php endif; ?>
              <?php if(Route::has('admin.proofs')): ?>
                <li><a href="<?php echo e(route('admin.proofs')); ?>" class="block px-2 py-1 <?php echo e(request()->routeIs('admin.proofs') ? 'underline font-semibold' : ''); ?>">Bukti SIAK</a></li>
              <?php endif; ?>
              <?php if($role === 'admin' && Route::has('admin.users')): ?>
                <li><a href="<?php echo e(route('admin.users')); ?>" class="block px-2 py-1 <?php echo e(request()->routeIs('admin.users') ? 'underline font-semibold' : ''); ?>">Manajemen User</a></li>
              <?php endif; ?>
            <?php endif; ?>

            <?php if(Route::has('logout')): ?>
              <li>
                <a href="#" class="block px-2 py-1 text-red-600"
                   onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                  Logout
                </a>
              </li>
            <?php endif; ?>
          <?php else: ?>
            <?php if(Route::has('login')): ?>
              <li><a href="<?php echo e(route('login')); ?>" class="block px-2 py-1">Login</a></li>
            <?php endif; ?>
            <?php if(Route::has('register')): ?>
              <li><a href="<?php echo e(route('register')); ?>" class="block px-2 py-1">Register</a></li>
            <?php endif; ?>
          <?php endif; ?>
        </ul>
      </div>
    </div>
  </nav>

  <?php if(Route::has('logout')): ?>
  <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="hidden">
    <?php echo csrf_field(); ?>
  </form>
  <?php endif; ?>

  
  <main class="flex-1 mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8 py-6">
    <?php echo $__env->yieldContent('content'); ?>
  </main>

  
  <?php $isAdmin = isset($role) && $role === 'admin'; ?>
  <footer class="mt-10 border-t bg-white/80 backdrop-blur supports-[backdrop-filter]:bg-white/60">
    <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-4
                text-sm text-gray-500 flex flex-col sm:flex-row items-center justify-between gap-2">

      <p class="order-2 sm:order-1">
        © <?php echo e(date('Y')); ?> KonserScan. All rights reserved.
      </p>
    </div>
  </footer>

  
  <script>
    const btn = document.getElementById('navToggle');
    const dropdown = document.getElementById('mobileMenu');
    if (btn) {
      btn.addEventListener('click', () => {
        dropdown.classList.toggle('hidden');
      });
    }
  </script>

  <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\Coding FullStack\konserscan\konser-tiket\resources\views\layouts\app.blade.php ENDPATH**/ ?>