<?php $__env->startSection('title','Scan Tiket'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
  <form method="POST" action="<?php echo e(route('scan.validate')); ?>">
    <?php echo csrf_field(); ?>
    <input name="kode" autofocus placeholder="Arahkan scanner ke sini">
    <button>Validasi</button>
  </form>
</div>

<?php if(session('msg')): ?>
  <div class="card"><strong><?php echo e(session('msg')); ?></strong></div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Coding FullStack\konserscan\konser-tiket\resources\views\scan\index.blade.php ENDPATH**/ ?>