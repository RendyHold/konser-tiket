<?php $__env->startSection('content'); ?>
<div class="container mx-auto max-w-3xl p-4">
  <h1 class="text-2xl font-bold mb-4">Tiket Saya</h1>

  <?php if($tickets->isEmpty()): ?>
    <p class="text-gray-600">Belum ada tiket.</p>
  <?php else: ?>
    <table class="w-full border">
      <thead>
        <tr class="bg-gray-100">
          <th class="p-2 border">Kode</th>
          <th class="p-2 border">QR</th>
          <th class="p-2 border">Status</th>
          <th class="p-2 border">Waktu Scan</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td class="p-2 border align-top">
            <div class="font-mono"><?php echo e($t->code); ?></div>
            <?php if(isset($t->npm)): ?>
              <div class="text-xs text-gray-500">NPM: <?php echo e($t->npm); ?></div>
            <?php endif; ?>
          </td>
          <td class="p-2 border">
            
            <?php echo QrCode::size(180)->margin(1)->generate($t->code); ?>

          </td>
          <td class="p-2 border align-top"><?php echo e($t->status ?? '-'); ?></td>
          <td class="p-2 border align-top">
            <?php echo e($t->scanned_at ? $t->scanned_at->format('d M Y H:i') : '-'); ?>

          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Coding FullStack\konserscan\konser-tiket\resources\views\ticket\show.blade.php ENDPATH**/ ?>