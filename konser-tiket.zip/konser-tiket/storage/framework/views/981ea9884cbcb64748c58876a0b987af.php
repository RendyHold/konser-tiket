<?php $__env->startSection('content'); ?>
<div class="max-w-6xl mx-auto space-y-6">
  <div>
    <h1 class="text-xl font-semibold">Manajemen User</h1>
    <p class="text-sm text-gray-500">Kelola role & akun pengguna</p>
  </div>

  <?php if(session('ok')): ?>
    <div class="rounded-md border border-green-200 bg-green-50 p-3 text-green-800">
      <?php echo e(session('ok')); ?>

    </div>
  <?php endif; ?>
  <?php if(session('err')): ?>
    <div class="rounded-md border border-red-200 bg-red-50 p-3 text-red-700">
      <?php echo e(session('err')); ?>

    </div>
  <?php endif; ?>

  <div class="rounded-xl border bg-white shadow-sm overflow-hidden">
    <table class="min-w-full text-sm">
      <thead class="bg-gray-50 text-left">
        <tr>
          <th class="px-4 py-3">Nama</th>
          <th class="px-4 py-3">Email</th>
          <th class="px-4 py-3">Role</th>
          <th class="px-4 py-3">Aksi</th>
        </tr>
      </thead>
      <tbody class="divide-y">
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td class="px-4 py-3"><?php echo e($u->name); ?></td>
            <td class="px-4 py-3"><?php echo e($u->email); ?></td>
            <td class="px-4 py-3">
              <span class="rounded px-2 py-0.5 text-xs ring-1
                <?php if($u->role==='admin'): ?> bg-purple-50 text-purple-700 ring-purple-200
                <?php elseif($u->role==='petugas'): ?> bg-blue-50 text-blue-700 ring-blue-200
                <?php else: ?> bg-gray-50 text-gray-700 ring-gray-200
                <?php endif; ?>">
                <?php echo e($u->role ?? 'user'); ?>

              </span>
            </td>

            <td class="px-4 py-3">
              
              <?php if($u->id !== auth()->id()): ?>

                
                <?php if(auth()->user()->role === 'admin'): ?>
                  <?php if($u->role === 'user'): ?>
                    <form method="POST" action="<?php echo e(route('admin.users.make-petugas', $u)); ?>" class="inline">
                      <?php echo csrf_field(); ?>
                      <button class="px-3 py-1 rounded bg-indigo-600 text-white hover:bg-indigo-700">
                        Jadikan Petugas
                      </button>
                    </form>
                  <?php elseif($u->role === 'petugas'): ?>
                    <form method="POST" action="<?php echo e(route('admin.users.revoke-petugas', $u)); ?>" class="inline">
                      <?php echo csrf_field(); ?>
                      <button class="px-3 py-1 rounded bg-gray-800 text-white hover:bg-black">
                        Cabut Petugas
                      </button>
                    </form>
                  <?php endif; ?>
                <?php endif; ?>

                
                <form action="<?php echo e(route('admin.users.destroy', $u)); ?>" method="POST"
                      class="inline"
                      onsubmit="return confirm('Hapus akun <?php echo e($u->name); ?>? Semua tiketnya juga akan dihapus.');">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button class="px-3 py-1 rounded bg-red-600 text-white hover:bg-red-700">
                    Hapus
                  </button>
                </form>

              <?php else: ?>
                <span class="text-gray-400 text-xs">—</span>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>

  <div><?php echo e($users->links()); ?></div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Coding FullStack\konserscan\konser-tiket\resources\views\admin\users.blade.php ENDPATH**/ ?>