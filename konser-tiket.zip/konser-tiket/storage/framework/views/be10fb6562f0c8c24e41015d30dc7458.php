<?php $__env->startSection('content'); ?>
<div class="container mx-auto max-w-xl px-4 py-6">
  <h1 class="text-2xl font-bold tracking-tight mb-6">Claim Tiket</h1>

  
  <?php if($errors->any()): ?>
    <div class="mb-6 rounded-md border border-red-200 bg-red-50 p-4 text-red-700">
      <div class="font-semibold mb-2">Terdapat kesalahan pada form:</div>
      <ul class="list-disc pl-5 space-y-1">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
  <?php endif; ?>

  <form action="<?php echo e(route('ticket.claim')); ?>" method="POST" class="space-y-5" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>

    
    <div>
      <label for="npm" class="block text-sm font-medium mb-1">
        Nomor Pokok Mahasiswa (NPM)
      </label>
      <input
        type="text"
        name="npm"
        id="npm"
        value="<?php echo e(old('npm')); ?>"
        required
        class="w-full rounded border px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 <?php $__errorArgs = ['npm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
      >
      <p class="mt-1 text-xs text-gray-500">Satu NPM hanya dapat generate 1 tiket.</p>
      <?php $__errorArgs = ['npm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    
    <div>
      <label for="bukti_npm" class="block text-sm font-medium mb-1">
        Upload SS SIAK <span class="text-red-600">*</span>
      </label>
      <input
        type="file"
        name="bukti_npm"
        id="bukti_npm"
        required
        accept=".jpg,.jpeg,.png,.webp,.pdf"
        class="block w-full text-sm file:mr-4 file:rounded file:border-0 file:bg-blue-600 file:px-4 file:py-2 file:text-white hover:file:bg-blue-700 <?php $__errorArgs = ['bukti_npm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
      >
      <p class="mt-1 text-xs text-gray-500">
        Format yang diterima: JPG/PNG/WebP/PDF. Maksimal 4&nbsp;MB.
      </p>
      <?php $__errorArgs = ['bukti_npm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    
    <div class="pt-2">
      <button
        type="submit"
        class="inline-flex items-center rounded bg-blue-600 px-4 py-2 font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
      >
        Claim Tiket
      </button>
      <a href="<?php echo e(route('ticket.show')); ?>" class="ml-3 text-sm text-gray-600 hover:underline">
        Lihat tiket saya
      </a>
    </div>
  </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Coding FullStack\konserscan\konser-tiket\resources\views\ticket\form.blade.php ENDPATH**/ ?>