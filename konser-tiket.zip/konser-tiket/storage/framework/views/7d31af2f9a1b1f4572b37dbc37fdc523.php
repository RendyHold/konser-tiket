<?php $__env->startSection('title','Form Pendaftaran'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
  <?php if($errors->any()): ?>
    <div class="err">
      <ul style="margin:0;padding-left:18px;">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($e); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
  <?php endif; ?>

  <form method="POST" action="<?php echo e(route('daftar.store')); ?>">
    <?php echo csrf_field(); ?>
    <p><label>NPM</label><br><input name="npm" value="<?php echo e(old('npm')); ?>" required></p>
    <p><label>Nama</label><br><input name="nama" value="<?php echo e(old('nama')); ?>" required></p>
    <p><label>Email</label><br><input type="email" name="email" value="<?php echo e(old('email')); ?>"></p>
    <p><label>No HP</label><br><input name="no_hp" value="<?php echo e(old('no_hp')); ?>"></p>

    <p>
      <label>Pilih Acara</label><br>
      <select name="acara_id" required>
        <option value="">-- pilih --</option>
        <?php $__currentLoopData = $acara; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($a->id); ?>" <?php if(old('acara_id')==$a->id): echo 'selected'; endif; ?>>
            <?php echo e($a->nama); ?> � <?php echo e($a->tanggal->format('d M Y H:i')); ?>

          </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </p>

    <button type="submit">Daftar</button>
  </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Coding FullStack\konserscan\konser-tiket\resources\views\daftar\form.blade.php ENDPATH**/ ?>